#仿今日头条微信小程序
##一款模仿今日头条风格的简单微信小程序，实现：新闻展示、评论展示功能。
首页效果图：
![首页效果图](https://github.com/winterfeel/Wxapp_Toutiao/blob/master/preview/1.png)

详情效果图：
![首页效果图](https://github.com/winterfeel/Wxapp_Toutiao/blob/master/preview/2.png)

评论效果图：
![首页效果图](https://github.com/winterfeel/Wxapp_Toutiao/blob/master/preview/3.png)


##说明
  我是个独立开发者，喜欢自己做App产品。因此更享受产品设计的过程，代码可能质量没有专业的高、没有那么严谨，仅供大家学习。

  开发过程我写在了简书中：
  
  [《灯灯小程序开发手记：仿今日头条（上）》](http://www.jianshu.com/p/a1e0b8abb12d)

  [《灯灯小程序开发手记：仿今日头条（下）》](http://www.jianshu.com/p/b17933c238d7)
  
**代码中没有实现登陆、发表评论功能，原因没有appid**

**代码中的api地址没有公布，涉及到其他产品，请使用自己的后台地址**

##感谢
最后感谢大家的支持，觉得有用的欢迎star！

作者：不灭的小灯灯

博客：[www.winterfeel.com](www.winterfeel.com)