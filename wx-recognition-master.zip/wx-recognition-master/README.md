# wx-recognition
微信小程序语音识别、图片识别、扫码识别功能

record_voice 是微信小程序工程

koa2_record_voice  是小程序后台服务器工程


[功能实现讲解doc](http://www.jianshu.com/p/b092da81feb0)
