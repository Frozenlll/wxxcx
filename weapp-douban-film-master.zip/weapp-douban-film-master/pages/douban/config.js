module.exports = {
    baiduAK: '7VENmCeC4aaAfx3CKbSjT1K3oRucOgDK'
}