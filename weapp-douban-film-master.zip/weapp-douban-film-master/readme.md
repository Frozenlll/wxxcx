# 微信小程序 - 豆瓣电影

如果要在手机上预览，因为程序包大小限制，需删掉`image/preview.gif`，并且需在公众号设置域名：
```
https://api.map.baidu.com
https://api.douban.com
```

![image/preview.gif](image/preview.gif)
