App({
  onLaunch: function () {
  },
  onShow: function () {
  },
  onHide: function () {
  },
  globalData: {
  }
})
