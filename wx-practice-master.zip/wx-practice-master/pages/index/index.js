Page({
    data: {
        list: [
            {
                name: 'Dialog',
                path: '/pages/dialog/index'
            },
            {
                name: 'Picker',
                path: '/pages/picker/index'
            },
        ]
    },

    onLoad: function () {

    }
});
